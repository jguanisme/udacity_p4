#**Advanced Lane Finding** 

##Writeup Template

###You can use this file as a template for your writeup if you want to submit it as a markdown file, but feel free to use some other method and submit a pdf if you prefer.

---

**Build a Advanced Lane Finding Project**

1,using all of the chess images to collect more data for calibrating .
2,undistorting will change the size of image
3,threshold can control the sensitivity of the algorithm
4,the image size must be 1280x720 when write a mp4 video
